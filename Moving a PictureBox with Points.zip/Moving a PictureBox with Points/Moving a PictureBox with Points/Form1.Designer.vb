﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMoveImage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnRight = New System.Windows.Forms.Button()
        Me.btnLeft = New System.Windows.Forms.Button()
        Me.btnUp = New System.Windows.Forms.Button()
        Me.btnDown = New System.Windows.Forms.Button()
        Me.imgCookie = New System.Windows.Forms.PictureBox()
        Me.imgPacMan = New System.Windows.Forms.PictureBox()
        Me.imgRock = New System.Windows.Forms.PictureBox()
        Me.imgRock2 = New System.Windows.Forms.PictureBox()
        Me.imgRock3 = New System.Windows.Forms.PictureBox()
        CType(Me.imgCookie, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPacMan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRock2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRock3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnRight
        '
        Me.btnRight.Location = New System.Drawing.Point(302, 396)
        Me.btnRight.Name = "btnRight"
        Me.btnRight.Size = New System.Drawing.Size(48, 23)
        Me.btnRight.TabIndex = 0
        Me.btnRight.Text = "Right"
        Me.btnRight.UseVisualStyleBackColor = True
        '
        'btnLeft
        '
        Me.btnLeft.Location = New System.Drawing.Point(213, 396)
        Me.btnLeft.Name = "btnLeft"
        Me.btnLeft.Size = New System.Drawing.Size(48, 23)
        Me.btnLeft.TabIndex = 1
        Me.btnLeft.Text = "Left"
        Me.btnLeft.UseVisualStyleBackColor = True
        '
        'btnUp
        '
        Me.btnUp.Location = New System.Drawing.Point(259, 367)
        Me.btnUp.Name = "btnUp"
        Me.btnUp.Size = New System.Drawing.Size(44, 23)
        Me.btnUp.TabIndex = 2
        Me.btnUp.Text = "Up"
        Me.btnUp.UseVisualStyleBackColor = True
        '
        'btnDown
        '
        Me.btnDown.Location = New System.Drawing.Point(259, 425)
        Me.btnDown.Name = "btnDown"
        Me.btnDown.Size = New System.Drawing.Size(44, 23)
        Me.btnDown.TabIndex = 3
        Me.btnDown.Text = "Down"
        Me.btnDown.UseVisualStyleBackColor = True
        '
        'imgCookie
        '
        Me.imgCookie.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.Cookie
        Me.imgCookie.Location = New System.Drawing.Point(149, 80)
        Me.imgCookie.Name = "imgCookie"
        Me.imgCookie.Size = New System.Drawing.Size(34, 34)
        Me.imgCookie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgCookie.TabIndex = 5
        Me.imgCookie.TabStop = False
        '
        'imgPacMan
        '
        Me.imgPacMan.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.PacRight
        Me.imgPacMan.Location = New System.Drawing.Point(259, 153)
        Me.imgPacMan.Name = "imgPacMan"
        Me.imgPacMan.Size = New System.Drawing.Size(67, 64)
        Me.imgPacMan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgPacMan.TabIndex = 4
        Me.imgPacMan.TabStop = False
        '
        'imgRock
        '
        Me.imgRock.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.rock
        Me.imgRock.Location = New System.Drawing.Point(292, 30)
        Me.imgRock.Name = "imgRock"
        Me.imgRock.Size = New System.Drawing.Size(91, 73)
        Me.imgRock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgRock.TabIndex = 6
        Me.imgRock.TabStop = False
        '
        'imgRock2
        '
        Me.imgRock2.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.rock
        Me.imgRock2.Location = New System.Drawing.Point(119, 212)
        Me.imgRock2.Name = "imgRock2"
        Me.imgRock2.Size = New System.Drawing.Size(91, 73)
        Me.imgRock2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgRock2.TabIndex = 8
        Me.imgRock2.TabStop = False
        '
        'imgRock3
        '
        Me.imgRock3.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.rock
        Me.imgRock3.Location = New System.Drawing.Point(383, 212)
        Me.imgRock3.Name = "imgRock3"
        Me.imgRock3.Size = New System.Drawing.Size(91, 73)
        Me.imgRock3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgRock3.TabIndex = 9
        Me.imgRock3.TabStop = False
        '
        'frmMoveImage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(589, 500)
        Me.Controls.Add(Me.imgRock3)
        Me.Controls.Add(Me.imgRock2)
        Me.Controls.Add(Me.imgRock)
        Me.Controls.Add(Me.imgCookie)
        Me.Controls.Add(Me.imgPacMan)
        Me.Controls.Add(Me.btnDown)
        Me.Controls.Add(Me.btnUp)
        Me.Controls.Add(Me.btnLeft)
        Me.Controls.Add(Me.btnRight)
        Me.Name = "frmMoveImage"
        Me.Text = "Move Image"
        CType(Me.imgCookie, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPacMan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgRock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgRock2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgRock3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnRight As Button
    Friend WithEvents btnLeft As Button
    Friend WithEvents btnUp As Button
    Friend WithEvents btnDown As Button
    Friend WithEvents imgPacMan As PictureBox
    Friend WithEvents imgCookie As PictureBox
    Friend WithEvents imgRock As PictureBox
    Friend WithEvents imgRock2 As PictureBox
    Friend WithEvents imgRock3 As PictureBox
End Class
