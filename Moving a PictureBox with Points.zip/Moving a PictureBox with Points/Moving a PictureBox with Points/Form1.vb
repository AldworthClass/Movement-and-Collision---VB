﻿
Public Class frmMoveImage
    Dim intSpeed As Integer
    Dim strDirection As String
    Dim Rocks As New List(Of PictureBox)    'Barriers will be stored here

    '*********FIX TO USE LEFT AND TOP PROPERTIES INSTEAD OF ALWAYS USING NEW POINTS

    Private Sub btnRight_Click(sender As Object, e As EventArgs) Handles btnRight.Click
        Dim bolSafeMove As Boolean = True
        Dim tempRect As Rectangle
        tempRect = New Rectangle(imgPacMan.Location.X + intSpeed, imgPacMan.Location.Y, imgPacMan.Width, imgPacMan.Height)

        'Checks to see if part of PacMan will be off the edge of the Form
        If imgPacMan.Right + intSpeed > Me.ClientSize.Width Then
            imgPacMan.Left = Me.ClientSize.Width - imgPacMan.Width  'Place Pacman right at the edge of the Form
            bolSafeMove = False 'Indicates that a normal move by intSPeed should not be done
        End If

        'Looks for collisions with impassible objects
        For Each rock In Rocks
            If tempRect.IntersectsWith(rock.Bounds) Then
                'We will set PacMan up against the left side of our obstacle if a move will put him in collision with it.
                imgPacMan.Left = rock.Location.X - imgPacMan.Width
                bolSafeMove = False 'Indicates that a normal move by intSpeed should not be done
            End If
        Next
        If bolSafeMove Then      'Will apply a normal move if no problems detected.
            imgPacMan.Left += intSpeed
        End If

        'Will only change the image in imgPacMan if the direction he is facing changes
        If strDirection <> "right" Then
            strDirection = "right"
            imgPacMan.Image = My.Resources.PacRight
        End If

        'Checks for collision with consumable object after move has been made.
        If imgPacMan.Bounds.IntersectsWith(imgCookie.Bounds) Then   'Could use contains() instead
            imgCookie.Visible = False
        End If


    End Sub

    Private Sub frmMoveImage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        intSpeed = 5
        strDirection = "right"  'Starting direction
        Rocks.Add(imgRock)
        Rocks.Add(imgRock2)
        Rocks.Add(imgRock3)
    End Sub

    Private Sub btnUp_Click(sender As Object, e As EventArgs) Handles btnUp.Click
        Dim bolSafeMove As Boolean = True
        Dim tempRect As Rectangle
        tempRect = New Rectangle(imgPacMan.Location.X, imgPacMan.Location.Y - intSpeed, imgPacMan.Width, imgPacMan.Height)
        'Checks to see of part of PacMan will be off the top of the Form. 
        If imgPacMan.Top < 0 Then
            imgPacMan.Top = 0 'PacMan is at the top edge of the Form
            bolSafeMove = False
        End If

        'Checks for collision with barrier
        For Each rock In Rocks
            If tempRect.IntersectsWith(rock.Bounds) Then
                'We will set PacMan up against the bottom of our obstacle if a normal move will put him in collision with it.
                imgPacMan.Top = rock.Bottom
                bolSafeMove = False 'Indicates that a normal move by intSpeed should not be done
            End If
        Next
        If bolSafeMove Then     'Will apply a normal move if no problems detected.
            imgPacMan.Top -= intSpeed
        End If

        'Will only change the image in imgPacMan if the direction he is facing changes
        If strDirection <> "up" Then
            strDirection = "up"
            imgPacMan.Image = My.Resources.PacUp
        End If

        'Checks for collision with consumable object after move has been made.
        If imgPacMan.Bounds.IntersectsWith(imgCookie.Bounds) Then   'Could use contains() instead
            imgCookie.Visible = False
        End If

    End Sub

    Private Sub btnDown_Click(sender As Object, e As EventArgs) Handles btnDown.Click
        Dim bolSafeMove As Boolean = True
        Dim tempRect As Rectangle
        tempRect = New Rectangle(imgPacMan.Location.X, imgPacMan.Location.Y + intSpeed, imgPacMan.Width, imgPacMan.Height)

        'Keeps PacMan from going off the bottom of the Form.
        If imgPacMan.Bottom + intSpeed > Me.ClientSize.Height Then
            imgPacMan.Top = Me.ClientSize.Height - imgPacMan.Height 'Puts PacMan against the bottom of the Form.
            bolSafeMove = False
        End If

        'Checks for collision with barrier
        For Each rock In Rocks
            If tempRect.IntersectsWith(rock.Bounds) Then
                'We will set PacMan up against the bottom of our obstacle if a normal move will put him in collision with it.
                imgPacMan.Top = rock.Top - imgPacMan.Height
                bolSafeMove = False 'Indicates that a normal move by intSpeed should not be done
            End If
        Next

        If bolSafeMove Then 'Will apply a normal move if no problems detected.
            imgPacMan.Top += intSpeed
        End If
        'Will only change the image in imgPacMan if the direction he is facing changes
        If strDirection <> "down" Then
            strDirection = "down"
            imgPacMan.Image = My.Resources.PacDown
        End If

        'Checks for collision with consumable object after move has been made.
        If imgPacMan.Bounds.IntersectsWith(imgCookie.Bounds) Then   'Could use contains() instead
            imgCookie.Visible = False
        End If
    End Sub

    Private Sub btnLeft_Click(sender As Object, e As EventArgs) Handles btnLeft.Click
        Dim bolSafeMove As Boolean = True
        Dim tempRect As Rectangle
        tempRect = New Rectangle(imgPacMan.Location.X - intSpeed, imgPacMan.Location.Y, imgPacMan.Width, imgPacMan.Height)

        'Makes sure PacMan doesn't leave the Form
        If imgPacMan.Left < 0 Then 'Our future location will be off the Form
            imgPacMan.Left = 0  'Puts PacMan on the Left edge of the Form.
            bolSafeMove = False
        End If

        'Checks for collision with barrier
        For Each rock In Rocks
            If tempRect.IntersectsWith(rock.Bounds) Then
                imgPacMan.Left = rock.Right 'Sets the left side of PacMan against the right side of the rock
                bolSafeMove = False
            End If
        Next

        If bolSafeMove Then 'Will apply a normal move if no problems detected.
            imgPacMan.Left -= intSpeed
        End If

        'Will only change the image in imgPacMan if the direction he is facing changes
        If strDirection <> "left" Then
            strDirection = "left"
            imgPacMan.Image = My.Resources.PacLeft
        End If

        'Checks for collision with consumable object after move has been made.
        If imgPacMan.Bounds.IntersectsWith(imgCookie.Bounds) Then   'Could use contains() instead
            imgCookie.Visible = False
        End If
    End Sub
End Class
